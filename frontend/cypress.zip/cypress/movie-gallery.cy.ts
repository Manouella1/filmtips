describe('movie-gallery.cy.ts', () => {
  it('playground', () => {
    // cy.mount()
  })
})
